import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, Upload, AlertCircle, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

// Import API functions (you would create these in a separate file)
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';

// API Helper functions
const apiRequest = async (endpoint, options = {}) => {
  const url = `${API_BASE_URL}${endpoint}`;
  const config = {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  };

  try {
    const response = await fetch(url, config);

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return { success: true, data };
  } catch (error) {
    console.error('API Request Error:', error);
    return { success: false, error: error.message };
  }
};

const uploadPatientImage = async (file) => {
  const formData = new FormData();
  formData.append('image', file);

  try {
    const response = await fetch(`${API_BASE_URL}/patients/upload-image`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return { success: true, data };
  } catch (error) {
    console.error('Image Upload Error:', error);
    return { success: false, error: error.message };
  }
};

const savePatientData = async (patientData, allergies, emergencyContacts, imageUrl = null) => {
  const payload = {
    patientData: {
      ...patientData,
      imageUrl
    },
    allergies: allergies || [], // ป้องกัน undefined
    emergencyContacts: emergencyContacts || [] // ป้องกัน undefined
  };

  return await apiRequest('/patients', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
};

const checkHNExists = async (hn) => {
  return await apiRequest(`/patients/check-hn/${hn}`);
};
const getGeneratedHN = async () => {
  return await apiRequest('/patients/generate-next-hn'); // Update this path to match your router file
};
const getProvinces = async () => {
  return await apiRequest('/location/provinces');
};

// FileUpload Component with API integration
const FileUpload = ({ onFileUpload, isUploading }) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [uploadStatus, setUploadStatus] = useState(null);

  const handleFileSelect = async (event) => {
    const file = event.target.files[0];
    if (file && file.type.startsWith('image/')) {
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);

      // Upload image to server
      setUploadStatus('uploading');
      const result = await uploadPatientImage(file);

      if (result.success && result.data) {
        setUploadStatus('success');
        onFileUpload(result.data.imageUrl);
      } else {
        setUploadStatus('error');
        console.error('Upload failed:', result.error);
      }
    }
  };

  return (
    <div className="w-full">
      <input
        type="file"
        id="imageUpload"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
        disabled={isUploading}
      />
      <label
        htmlFor="imageUpload"
        className="cursor-pointer flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-gray-300 rounded-lg hover:border-gray-400 transition-colors"
      >
        {previewUrl ? (
          <div className="relative w-full h-full">
            <img
              src={previewUrl}
              alt="Preview"
              className="w-full h-full object-cover rounded-lg"
            />
            {uploadStatus === 'uploading' && (
              <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded-lg">
                <div className="text-white text-sm">กำลังอัพโหลด...</div>
              </div>
            )}
            {uploadStatus === 'success' && (
              <div className="absolute top-2 right-2">
                <CheckCircle className="w-6 h-6 text-green-500" />
              </div>
            )}
            {uploadStatus === 'error' && (
              <div className="absolute top-2 right-2">
                <AlertCircle className="w-6 h-6 text-red-500" />
              </div>
            )}
          </div>
        ) : (
          <>
            <Upload className="w-8 h-8 text-gray-400 mb-2" />
            <p className="text-sm text-gray-500">คลิกเพื่ออัพโหลดรูปภาพ</p>
          </>
        )}
      </label>
    </div>
  );
};

// InputField Component with validation
const InputField = ({ label, placeholder, type = "text", value, onChange, error, onBlur, required = false }) => {
  return (
    <div className="flex flex-col">
      <label className="text-sm font-medium text-gray-700 mb-2">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <input
        type={type}
        placeholder={placeholder}
        value={value || ''} // ป้องกัน null/undefined
        onChange={onChange}
        onBlur={onBlur}
        className={`px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent ${error ? 'border-red-500' : 'border-gray-300'
          }`}
      />
      {error && <span className="text-red-500 text-xs mt-1">{error}</span>}
    </div>
  );
};

// SelectField Component with API data
const SelectField = ({ label, options, value, onChange, placeholder, error, required = false, loading = false }) => {
  // ป้องกัน null/undefined สำหรับ options
  const safeOptions = options || [];

  return (
    <div className="flex flex-col">
      <label className="text-sm font-medium text-gray-700 mb-2">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <select
        value={value || ''} // ป้องกัน null/undefined
        onChange={onChange}
        className={`px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent ${error ? 'border-red-500' : 'border-gray-300'
          }`}
        disabled={loading}
      >
        <option value="">{loading ? 'กำลังโหลด...' : placeholder}</option>
        {safeOptions.map((option, index) => (
          <option key={option.value || index} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {error && <span className="text-red-500 text-xs mt-1">{error}</span>}
    </div>
  );
};

// Toast notification component
const Toast = ({ message, type, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 5000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className={`fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${type === 'success' ? 'bg-green-500' :
      type === 'error' ? 'bg-red-500' : 'bg-blue-500'
      } text-white`}>
      <div className="flex items-center space-x-2">
        {type === 'success' && <CheckCircle className="w-5 h-5" />}
        {type === 'error' && <AlertCircle className="w-5 h-5" />}
        <span>{message}</span>
        <button onClick={onClose} className="ml-2">
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

const PatientForm = () => {
  const navigate = useNavigate();

  // Modal states
  const [isAllergyModalOpen, setIsAllergyModalOpen] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [isVNModalOpen, setIsVNModalOpen] = useState(false);
  const [newPatientId, setNewPatientId] = useState(null);

  // Loading states
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isImageUploading, setIsImageUploading] = useState(false);

  // Data states - ใส่ค่าเริ่มต้นให้ทุก array
  const [provinces, setProvinces] = useState([]);
  const [imageUrl, setImageUrl] = useState(null);

  // Toast notification
  const [toast, setToast] = useState(null);

  // Validation errors
  const [errors, setErrors] = useState({});

  // Patient data - ใส่ค่าเริ่มต้นให้ทุกฟิลด์
  const [patientData, setPatientData] = useState({
    hn: '',
    idCard: '',
    firstName: '',
    lastName: '',
    birthDate: '',
    age: '',
    gender: '',
    religion: '',
    nationality: 'ไทย',
    race: 'ไทย',
    bloodGroup: '',
    houseNumber: '',
    village: '',
    subDistrict: '',
    district: '',
    province: '',
    chronicDisease: '',
    contactPhone: ''
  });

  // Allergies data - ใส่ค่าเริ่มต้นเป็น array ว่าง
  const [allergies, setAllergies] = useState([]);
  const [newAllergy, setNewAllergy] = useState({
    type: 'drug',
    name: '',
    severity: 'mild',
    symptoms: '',
    notes: ''
  });

  // Emergency contacts data - ใส่ค่าเริ่มต้นเป็น array ว่าง
  const [emergencyContacts, setEmergencyContacts] = useState([]);
  const [newContact, setNewContact] = useState({
    name: '',
    relationship: '',
    phone: '',
    address: ''
  });

  // Load initial data
  useEffect(() => {
     loadProvinces();
    loadGeneratedHN(); // Call the new function to load the generated HN
  }, []);
  const loadGeneratedHN = async () => {
    setIsLoading(true);
    const result = await getGeneratedHN();
    console.log('Generated HN result:', result);
    if (result.success) {
      setPatientData(prev => ({
        ...prev,
        hn: result.data.data.hn
      }));
    } else {
      // Handle error case, maybe show a toast or a message
      showToast('ไม่สามารถสร้าง HN อัตโนมัติได้ กรุณากรอกเอง', 'error');
    }
    setIsLoading(false);
  };
  const loadProvinces = async () => {
    try {
      const result = await getProvinces();
      console.log('Provinces result:', result);
      if (result.success && result.data.data && Array.isArray(result.data.data)) {
        setProvinces(result.data.data.map(province => ({
          value: province.id,
          label: province.name
        })));
      } else {
        console.error('Failed to load provinces:', result.error);
        setProvinces([]); // ตั้งค่าเป็น array ว่างในกรณีที่ fail
        showToast('ไม่สามารถโหลดข้อมูลจังหวัดได้', 'error');
      }
    } catch (error) {
      console.error('Load provinces error:', error);
      setProvinces([]); // ตั้งค่าเป็น array ว่างในกรณีที่ error
      showToast('เกิดข้อผิดพลาดในการโหลดข้อมูล', 'error');
    }
  };

  const showToast = (message, type = 'info') => {
    setToast({ message, type });
  };

  const validateForm = () => {
    const newErrors = {};

    // Required fields validation
    if (!patientData.hn) newErrors.hn = 'กรุณากรอก HN';
    if (!patientData.idCard) newErrors.idCard = 'กรุณากรอกเลขบัตรประชาชน';
    if (!patientData.firstName) newErrors.firstName = 'กรุณากรอกชื่อ';
    if (!patientData.lastName) newErrors.lastName = 'กรุณากรอกนามสกุล';
    if (!patientData.birthDate) newErrors.birthDate = 'กรุณากรอกวันเกิด';
    if (!patientData.gender) newErrors.gender = 'กรุณาเลือกเพศ';

    // ID Card validation (13 digits)
    if (patientData.idCard && !/^\d{13}$/.test(patientData.idCard)) {
      newErrors.idCard = 'เลขบัตรประชาชนต้องเป็นตัวเลข 13 หลัก';
    }

    // Phone validation
    if (patientData.contactPhone && !/^\d{10}$/.test(patientData.contactPhone)) {
      newErrors.contactPhone = 'เบอร์โทรศัพท์ต้องเป็นตัวเลข 10 หลัก';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleHNBlur = async () => {
    if (patientData.hn) {
      try {
        const result = await checkHNExists(patientData.hn);
        if (result.success && result.data && result.data.exists) {
          setErrors(prev => ({ ...prev, hn: 'HN นี้มีอยู่ในระบบแล้ว' }));
        } else if (result.success) {
          setErrors(prev => ({ ...prev, hn: '' }));
        } else {
          console.error('HN check failed:', result.error);
        }
      } catch (error) {
        console.error('HN check error:', error);
      }
    }
  };

  const updatePatientData = (field, value) => {
    setPatientData(prev => ({
      ...prev,
      [field]: value
    }));

    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const handleImageUpload = (url) => {
    setImageUrl(url);
    showToast('อัพโหลดรูปภาพสำเร็จ', 'success');
  };

  // Modal functions
  const openAllergyModal = () => setIsAllergyModalOpen(true);
  const closeAllergyModal = () => {
    setIsAllergyModalOpen(false);
    setNewAllergy({
      type: 'drug',
      name: '',
      severity: 'mild',
      symptoms: '',
      notes: ''
    });
  };

  const openContactModal = () => setIsContactModalOpen(true);
  const closeContactModal = () => {
    setIsContactModalOpen(false);
    setNewContact({
      name: '',
      relationship: '',
      phone: '',
      address: ''
    });
  };

  const openConfirmModal = () => {
    if (validateForm()) {
      setIsConfirmModalOpen(true);
    } else {
      showToast('กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน', 'error');
    }
  };

  const closeConfirmModal = () => setIsConfirmModalOpen(false);
  const openVNModal = () => setIsVNModalOpen(true);
  const closeVNModal = () => setIsVNModalOpen(false);

  // Add allergy
  const addAllergy = () => {
    if (newAllergy.name.trim()) {
      setAllergies(prev => [...(prev || []), { ...newAllergy, id: Date.now() }]); // ป้องกัน undefined
      closeAllergyModal();
      showToast('เพิ่มข้อมูลการแพ้สำเร็จ', 'success');
    }
  };

  const removeAllergy = (id) => {
    setAllergies(prev => (prev || []).filter(allergy => allergy.id !== id)); // ป้องกัน undefined
    showToast('ลบข้อมูลการแพ้สำเร็จ', 'success');
  };

  // Add emergency contact
  const addContact = () => {
    if (newContact.name.trim() && newContact.relationship.trim() && newContact.phone.trim()) {
      // Validate phone number
      if (!/^\d{10}$/.test(newContact.phone)) {
        showToast('เบอร์โทรศัพท์ต้องเป็นตัวเลข 10 หลัก', 'error');
        return;
      }

      setEmergencyContacts(prev => [...(prev || []), { ...newContact, id: Date.now() }]); // ป้องกัน undefined
      closeContactModal();
      showToast('เพิ่มผู้ติดต่อฉุกเฉินสำเร็จ', 'success');
    } else {
      showToast('กรุณากรอกข้อมูลให้ครบถ้วน', 'error');
    }
  };

  const removeContact = (id) => {
    setEmergencyContacts(prev => (prev || []).filter(contact => contact.id !== id)); // ป้องกัน undefined
    showToast('ลบผู้ติดต่อฉุกเฉินสำเร็จ', 'success');
  };

  // Save data
  const handleSaveData = () => {
    openConfirmModal();
  };

  const confirmSave = async () => {
    setIsSaving(true);

    try {
     const result = await savePatientData(patientData, allergies, emergencyContacts, imageUrl);
console.log('Save patient result:', result);
      if (result.success && result.data.data && result.data.data.patientId) { // Check for the patientId in the response
        setNewPatientId(result.data.data.patientId); // Store the patient ID
        closeConfirmModal();
        openVNModal(); // Open the success modal
        showToast('บันทึกข้อมูลผู้ป่วยสำเร็จ', 'success');
      } else {
        showToast(`เกิดข้อผิดพลาด: ${result.error}`, 'error');
      }
    } catch (error) {
      showToast('เกิดข้อผิดพลาดในการบันทึกข้อมูล', 'error');
    } finally {
      setIsSaving(false);
    }
  };

 const goToAddPatientVN = () => {
    closeVNModal();
    // Pass the patientId as a state object
    navigate('/VNPatient', { state: { patientId: newPatientId } });
  };

  const goToPatientPage = () => {
    closeVNModal();
    navigate('/patients');
  };

  // Gender options
  const genderOptions = [
    { value: 'male', label: 'ชาย' },
    { value: 'female', label: 'หญิง' },
    { value: 'other', label: 'อื่นๆ' }
  ];

  // Blood group options
  const bloodGroupOptions = [
    { value: 'A', label: 'A' },
    { value: 'B', label: 'B' },
    { value: 'AB', label: 'AB' },
    { value: 'O', label: 'O' }
  ];

  // Religion options
  const religionOptions = [
    { value: 'buddhist', label: 'พุทธ' },
    { value: 'christian', label: 'คริสต์' },
    { value: 'islamic', label: 'อิสลาม' },
    { value: 'hindu', label: 'ฮินดู' },
    { value: 'other', label: 'อื่นๆ' }
  ];

  return (
    <div className="flex flex-col bg-gray-100 min-h-screen p-6">
      {/* Toast Notification */}
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}

      {/* Loading Overlay */}
      {isLoading && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-4 rounded-lg">
            <div className="text-center">กำลังโหลด...</div>
          </div>
        </div>
      )}

      {/* Form Container */}
      <div className="bg-white p-8 rounded-lg shadow-md">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-800">
            เพิ่มผู้รับบริการใหม่
          </h1>
        </div>

        {/* Personal Info Section */}
        <h2 className="text-xl font-semibold text-gray-800 mb-4">ข้อมูลส่วนตัว</h2>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Image Upload Column */}
          <div className="flex flex-col items-center justify-center p-4 border border-dashed border-gray-300 rounded-lg h-full">
            <FileUpload
              onFileUpload={handleImageUpload}
              isUploading={isImageUploading}
            />
          </div>

          {/* Form Fields Column */}
          <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField
              label="HN"
              placeholder="HN"
              value={patientData.hn}
              onChange={(e) => updatePatientData('hn', e.target.value)}
              onBlur={handleHNBlur}
              error={errors.hn}
              required
              readOnly={true} // เพิ่มบรรทัดนี้
            />
            <InputField
              label="เลขบัตรประชาชน"
              placeholder="เลขบัตรประชาชน"
              value={patientData.idCard}
              onChange={(e) => updatePatientData('idCard', e.target.value)}
              error={errors.idCard}
              required
            />
            <InputField
              label="ชื่อ"
              placeholder="ชื่อ"
              value={patientData.firstName}
              onChange={(e) => updatePatientData('firstName', e.target.value)}
              error={errors.firstName}
              required
            />
            <InputField
              label="นามสกุล"
              placeholder="นามสกุล"
              value={patientData.lastName}
              onChange={(e) => updatePatientData('lastName', e.target.value)}
              error={errors.lastName}
              required
            />
            <InputField
              label="วัน / เดือน / ปีเกิด"
              placeholder="วัน / เดือน / ปีเกิด"
              type="date"
              value={patientData.birthDate}
              onChange={(e) => updatePatientData('birthDate', e.target.value)}
              error={errors.birthDate}
              required
            />
            <InputField
              label="อายุ"
              placeholder="อายุ"
              type="number"
              value={patientData.age}
              onChange={(e) => updatePatientData('age', e.target.value)}
              error={errors.age}
            />
            <SelectField
              label="เพศ"
              options={genderOptions}
              value={patientData.gender}
              onChange={(e) => updatePatientData('gender', e.target.value)}
              placeholder="เลือกเพศ"
              error={errors.gender}
              required
            />
            <SelectField
              label="ศาสนา"
              options={religionOptions}
              value={patientData.religion}
              onChange={(e) => updatePatientData('religion', e.target.value)}
              placeholder="เลือกศาสนา"
            />
            <InputField
              label="สัญชาติ"
              placeholder="สัญชาติ"
              value={patientData.nationality}
              onChange={(e) => updatePatientData('nationality', e.target.value)}
            />
            <InputField
              label="เชื้อชาติ"
              placeholder="เชื้อชาติ"
              value={patientData.race}
              onChange={(e) => updatePatientData('race', e.target.value)}
            />
            <SelectField
              label="กรุ๊ปเลือด"
              options={bloodGroupOptions}
              value={patientData.bloodGroup}
              onChange={(e) => updatePatientData('bloodGroup', e.target.value)}
              placeholder="เลือกกรุ๊ปเลือด"
            />
          </div>
        </div>

        {/* Address Section */}
        <div className="mt-8">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">ที่อยู่ที่สามารถติดต่อได้</h2>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <InputField
              label="บ้านเลขที่"
              placeholder="บ้านเลขที่"
              value={patientData.houseNumber}
              onChange={(e) => updatePatientData('houseNumber', e.target.value)}
            />
            <InputField
              label="หมู่"
              placeholder="หมู่"
              value={patientData.village}
              onChange={(e) => updatePatientData('village', e.target.value)}
            />
            <InputField
              label="ตำบล"
              placeholder="ตำบล"
              value={patientData.subDistrict}
              onChange={(e) => updatePatientData('subDistrict', e.target.value)}
            />
            <InputField
              label="อำเภอ"
              placeholder="อำเภอ"
              value={patientData.district}
              onChange={(e) => updatePatientData('district', e.target.value)}
            />
            <SelectField
              label="จังหวัด"
              options={provinces}
              value={patientData.province}
              onChange={(e) => updatePatientData('province', e.target.value)}
              placeholder="เลือกจังหวัด"
            />
          </div>
        </div>

        {/* Medical Info Section */}
        <div className="mt-8">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">ข้อมูลทางการแพทย์</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField
              label="โรคประจำตัว"
              placeholder="โรคประจำตัว (ถ้ามี)"
              value={patientData.chronicDisease}
              onChange={(e) => updatePatientData('chronicDisease', e.target.value)}
            />
            <InputField
              label="เบอร์โทรศัพท์ติดต่อ"
              placeholder="เบอร์โทรศัพท์ติดต่อ"
              value={patientData.contactPhone}
              onChange={(e) => updatePatientData('contactPhone', e.target.value)}
              error={errors.contactPhone}
            />
          </div>

          <div className="mt-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-700">ข้อมูลการแพ้</h3>
              <button
                onClick={openAllergyModal}
                className="bg-green-500 text-white py-2 px-4 rounded-lg hover:bg-green-600 transition-colors flex items-center space-x-2"
              >
                <Plus className="h-4 w-4" />
                <span>เพิ่มข้อมูลแพ้</span>
              </button>
            </div>

            {/* Allergy Table */}
            {Array.isArray(allergies) && allergies.length > 0 && (
              <div className="mt-4 overflow-x-auto">
                <table className="w-full bg-white border border-gray-200 rounded-lg">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ชื่อสิ่งที่แพ้</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ระดับความรุนแรง</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">อาการ</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">หมายเหตุ</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">การกระทำ</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {allergies.map((allergy) => (
                      <tr key={allergy.id}>
                        <td className="px-4 py-4 whitespace-nowrap text-sm">
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${allergy.type === 'drug' ? 'bg-red-100 text-red-800' : 'bg-orange-100 text-orange-800'
                            }`}>
                            {allergy.type === 'drug' ? 'แพ้ยา' : 'แพ้อาหาร'}
                          </span>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{allergy.name}</td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm">
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${allergy.severity === 'severe' ? 'bg-red-100 text-red-800' :
                            allergy.severity === 'moderate' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-green-100 text-green-800'
                            }`}>
                            {allergy.severity === 'severe' ? 'รุนแรง' :
                              allergy.severity === 'moderate' ? 'ปานกลาง' : 'เล็กน้อย'}
                          </span>
                        </td>
                        <td className="px-4 py-4 text-sm text-gray-900 max-w-xs truncate">{allergy.symptoms}</td>
                        <td className="px-4 py-4 text-sm text-gray-900 max-w-xs truncate">{allergy.notes}</td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                          <button
                            onClick={() => removeAllergy(allergy.id)}
                            className="text-red-600 hover:text-red-800 transition-colors"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Emergency Contact Section */}
        <div className="mt-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-800">ผู้ติดต่อฉุกเฉิน</h2>
            <button
              onClick={openContactModal}
              className="bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors flex items-center space-x-2"
            >
              <Plus className="h-4 w-4" />
              <span>เพิ่มผู้ติดต่อฉุกเฉิน</span>
            </button>
          </div>

          {/* Emergency Contacts Table */}
          {Array.isArray(emergencyContacts) && emergencyContacts.length > 0 && (
            <div className="mt-4 overflow-x-auto">
              <table className="w-full bg-white border border-gray-200 rounded-lg">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ชื่อ-นามสกุล</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ความสัมพันธ์</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">เบอร์โทรศัพท์</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ที่อยู่</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">การกระทำ</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {emergencyContacts.map((contact) => (
                    <tr key={contact.id}>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">{contact.name}</td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm">
                        <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                          {contact.relationship}
                        </span>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{contact.phone}</td>
                      <td className="px-4 py-4 text-sm text-gray-900 max-w-xs truncate">{contact.address}</td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                        <button
                          onClick={() => removeContact(contact.id)}
                          className="text-red-600 hover:text-red-800 transition-colors"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-start space-x-4 mt-8">
        <button
          onClick={handleSaveData}
          disabled={isSaving}
          className="bg-green-600 text-white font-semibold py-2 px-6 rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center space-x-2"
        >
          {isSaving && (
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
          )}
          <span>{isSaving ? 'กำลังบันทึก...' : 'บันทึกข้อมูล'}</span>
        </button>
        <button
          onClick={() => navigate('/patients')}
          className="bg-red-600 text-white font-semibold py-2 px-6 rounded-lg hover:bg-red-700 transition-colors"
        >
          ยกเลิก
        </button>
      </div>

      {/* Allergy Modal */}
      {isAllergyModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-gray-800">เพิ่มข้อมูลการแพ้</h3>
              <button
                onClick={closeAllergyModal}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">ประเภทการแพ้</label>
                <select
                  value={newAllergy.type}
                  onChange={(e) => setNewAllergy({ ...newAllergy, type: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="drug">แพ้ยา</option>
                  <option value="food">แพ้อาหาร</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  ชื่อ{newAllergy.type === 'drug' ? 'ยา' : 'อาหาร'}ที่แพ้
                </label>
                <input
                  type="text"
                  value={newAllergy.name}
                  onChange={(e) => setNewAllergy({ ...newAllergy, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder={`กรอกชื่อ${newAllergy.type === 'drug' ? 'ยา' : 'อาหาร'}ที่แพ้`}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">ระดับความรุนแรง</label>
                <select
                  value={newAllergy.severity}
                  onChange={(e) => setNewAllergy({ ...newAllergy, severity: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="mild">เล็กน้อย</option>
                  <option value="moderate">ปานกลาง</option>
                  <option value="severe">รุนแรง</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">อาการที่เกิดขึ้น</label>
                <textarea
                  value={newAllergy.symptoms}
                  onChange={(e) => setNewAllergy({ ...newAllergy, symptoms: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows="3"
                  placeholder="อธิบายอาการที่เกิดขึ้น เช่น ผื่นคัน, บวม, หายใจลำบาก"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">หมายเหตุ</label>
                <textarea
                  value={newAllergy.notes}
                  onChange={(e) => setNewAllergy({ ...newAllergy, notes: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows="2"
                  placeholder="หมายเหตุเพิ่มเติม (ถ้ามี)"
                />
              </div>
            </div>

            <div className="flex justify-end space-x-3 mt-6">
              <button
                onClick={closeAllergyModal}
                className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                ยกเลิก
              </button>
              <button
                onClick={addAllergy}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                เพิ่มข้อมูล
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Emergency Contact Modal */}
      {isContactModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-gray-800">เพิ่มผู้ติดต่อฉุกเฉิน</h3>
              <button
                onClick={closeContactModal}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">ชื่อ-นามสกุล</label>
                <input
                  type="text"
                  value={newContact.name}
                  onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="กรอกชื่อ-นามสกุล"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">ความสัมพันธ์</label>
                <select
                  value={newContact.relationship}
                  onChange={(e) => setNewContact({ ...newContact, relationship: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">เลือกความสัมพันธ์</option>
                  <option value="บิดา">บิดา</option>
                  <option value="มารดา">มารดา</option>
                  <option value="สามี">สามี</option>
                  <option value="ภรรยา">ภรรยา</option>
                  <option value="บุตร">บุตร</option>
                  <option value="บุตรสาว">บุตรสาว</option>
                  <option value="พี่ชาย">พี่ชาย</option>
                  <option value="พี่สาว">พี่สาว</option>
                  <option value="น้องชาย">น้องชาย</option>
                  <option value="น้องสาว">น้องสาว</option>
                  <option value="ปู่">ปู่</option>
                  <option value="ย่า">ย่า</option>
                  <option value="ตา">ตา</option>
                  <option value="ยาย">ยาย</option>
                  <option value="เพื่อน">เพื่อน</option>
                  <option value="อื่นๆ">อื่นๆ</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">เบอร์โทรศัพท์</label>
                <input
                  type="tel"
                  value={newContact.phone}
                  onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="กรอกเบอร์โทรศัพท์"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">ที่อยู่</label>
                <textarea
                  value={newContact.address}
                  onChange={(e) => setNewContact({ ...newContact, address: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows="3"
                  placeholder="กรอกที่อยู่"
                />
              </div>
            </div>

            <div className="flex justify-end space-x-3 mt-6">
              <button
                onClick={closeContactModal}
                className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                ยกเลิก
              </button>
              <button
                onClick={addContact}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                เพิ่มข้อมูล
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirm Data Modal */}
      {isConfirmModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-4xl mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-gray-800">ตรวจสอบข้อมูลก่อนบันทึก</h3>
              <button
                onClick={closeConfirmModal}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="space-y-6">
              {/* Personal Info Review */}
              <div>
                <h4 className="text-md font-semibold text-gray-700 mb-3 border-b pb-2">ข้อมูลส่วนตัว</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div><span className="font-medium">HN:</span> {patientData.hn || '-'}</div>
                  <div><span className="font-medium">เลขบัตรประชาชน:</span> {patientData.idCard || '-'}</div>
                  <div><span className="font-medium">ชื่อ:</span> {patientData.firstName || '-'}</div>
                  <div><span className="font-medium">นามสกุล:</span> {patientData.lastName || '-'}</div>
                  <div><span className="font-medium">วันเกิด:</span> {patientData.birthDate || '-'}</div>
                  <div><span className="font-medium">อายุ:</span> {patientData.age || '-'}</div>
                  <div><span className="font-medium">เพศ:</span> {genderOptions.find(g => g.value === patientData.gender)?.label || '-'}</div>
                  <div><span className="font-medium">ศาสนา:</span> {religionOptions.find(r => r.value === patientData.religion)?.label || '-'}</div>
                  <div><span className="font-medium">สัญชาติ:</span> {patientData.nationality || '-'}</div>
                  <div><span className="font-medium">เชื้อชาติ:</span> {patientData.race || '-'}</div>
                  <div><span className="font-medium">กรุ๊ปเลือด:</span> {patientData.bloodGroup || '-'}</div>
                </div>
              </div>

              {/* Address Review */}
              <div>
                <h4 className="text-md font-semibold text-gray-700 mb-3 border-b pb-2">ที่อยู่</h4>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4 text-sm">
                  <div><span className="font-medium">บ้านเลขที่:</span> {patientData.houseNumber || '-'}</div>
                  <div><span className="font-medium">หมู่:</span> {patientData.village || '-'}</div>
                  <div><span className="font-medium">ตำบล:</span> {patientData.subDistrict || '-'}</div>
                  <div><span className="font-medium">อำเภอ:</span> {patientData.district || '-'}</div>
                  <div><span className="font-medium">จังหวัด:</span> {provinces.find(p => p.value === patientData.province)?.label || '-'}</div>
                </div>
              </div>

              {/* Medical Info Review */}
              <div>
                <h4 className="text-md font-semibold text-gray-700 mb-3 border-b pb-2">ข้อมูลทางการแพทย์</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm mb-4">
                  <div><span className="font-medium">โรคประจำตัว:</span> {patientData.chronicDisease || '-'}</div>
                  <div><span className="font-medium">เบอร์โทรศัพท์:</span> {patientData.contactPhone || '-'}</div>
                </div>

                {Array.isArray(allergies) && allergies.length > 0 && (
                  <div>
                    <h5 className="font-medium text-gray-600 mb-2">รายการสิ่งที่แพ้:</h5>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm border border-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-3 py-2 text-left">ประเภท</th>
                            <th className="px-3 py-2 text-left">ชื่อ</th>
                            <th className="px-3 py-2 text-left">ความรุนแรง</th>
                            <th className="px-3 py-2 text-left">อาการ</th>
                          </tr>
                        </thead>
                        <tbody>
                          {allergies.map((allergy, index) => (
                            <tr key={index} className="border-t">
                              <td className="px-3 py-2">{allergy.type === 'drug' ? 'แพ้ยา' : 'แพ้อาหาร'}</td>
                              <td className="px-3 py-2">{allergy.name}</td>
                              <td className="px-3 py-2">
                                <span className={`px-2 py-1 text-xs rounded-full ${allergy.severity === 'severe' ? 'bg-red-100 text-red-800' :
                                  allergy.severity === 'moderate' ? 'bg-yellow-100 text-yellow-800' :
                                    'bg-green-100 text-green-800'
                                  }`}>
                                  {allergy.severity === 'severe' ? 'รุนแรง' :
                                    allergy.severity === 'moderate' ? 'ปานกลาง' : 'เล็กน้อย'}
                                </span>
                              </td>
                              <td className="px-3 py-2">{allergy.symptoms}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>

              {/* Emergency Contacts Review */}
              {Array.isArray(emergencyContacts) && emergencyContacts.length > 0 && (
                <div>
                  <h4 className="text-md font-semibold text-gray-700 mb-3 border-b pb-2">ผู้ติดต่อฉุกเฉิน</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm border border-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-3 py-2 text-left">ชื่อ-นามสกุล</th>
                          <th className="px-3 py-2 text-left">ความสัมพันธ์</th>
                          <th className="px-3 py-2 text-left">เบอร์โทร</th>
                          <th className="px-3 py-2 text-left">ที่อยู่</th>
                        </tr>
                      </thead>
                      <tbody>
                        {emergencyContacts.map((contact, index) => (
                          <tr key={index} className="border-t">
                            <td className="px-3 py-2 font-medium">{contact.name}</td>
                            <td className="px-3 py-2">{contact.relationship}</td>
                            <td className="px-3 py-2">{contact.phone}</td>
                            <td className="px-3 py-2">{contact.address}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-end space-x-3 mt-6 border-t pt-4">
              <button
                onClick={closeConfirmModal}
                className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                แก้ไข
              </button>
              <button
                onClick={confirmSave}
                disabled={isSaving}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center space-x-2"
              >
                {isSaving && (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                )}
                <span>{isSaving ? 'กำลังบันทึก...' : 'ยืนยันบันทึก'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Success Modal */}
      {isVNModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <div className="text-center">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-800 mb-2">บันทึกข้อมูลสำเร็จ</h3>
              <p className="text-gray-600 mb-6">ข้อมูลผู้ป่วยได้ถูกบันทึกในระบบแล้ว</p>

              <div className="flex flex-col space-y-3">
                <button
                  onClick={goToAddPatientVN}
                  className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  เพิ่ม VN ใหม่
                </button>
                <button
                  onClick={goToPatientPage}
                  className="w-full bg-gray-600 text-white py-2 px-4 rounded-lg hover:bg-gray-700 transition-colors"
                >
                  กลับหน้าผู้ป่วย
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PatientForm;