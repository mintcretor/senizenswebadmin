import React, { useState, useEffect } from 'react';
import { Search, Calendar, Clock, User, ChevronDown, ChevronLeft, X } from 'lucide-react';

const PatientProcedureForm = () => {
  const [date, setDate] = useState(new Date().toLocaleDateString('th-TH'));
  const [time, setTime] = useState(new Date().toLocaleTimeString('th-TH'));
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [showPatientModal, setShowPatientModal] = useState(false);
  const [showProcedureModal, setShowProcedureModal] = useState(false);
  const [showOtherModal, setShowOtherModal] = useState(false);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [intolerance, setIntolerance] = useState('-');
  const [note, setNote] = useState('');
  
  // เก็บหัตถการพร้อมผู้ปฏิบัติ: {name, performedBy, subOption}
  const [selectedProcedures, setSelectedProcedures] = useState([]);
  const [checkedOther, setCheckedOther] = useState([]);
  
  const [oxygenHour, setOxygenHour] = useState('');
  const [infusionNG, setInfusionNG] = useState('');
  const [infusionIV, setInfusionIV] = useState('');
  
  const [showOxygenOptions, setShowOxygenOptions] = useState(false);
  const [showInfusionNGOptions, setShowInfusionNGOptions] = useState(false);
  const [showInfusionIVOptions, setShowInfusionIVOptions] = useState(false);

  // Mock patient data
  const [patients] = useState([
    { id: 1, patient_id: 'P001', prefix: 'นาย', firstname: 'สมชาย', lastname: 'ใจดี', age: '65 ปี', hn: 'HN001', room: '101', image: '/api/placeholder/80/80' },
    { id: 2, patient_id: 'P002', prefix: 'นาง', firstname: 'สมหญิง', lastname: 'มีสุข', age: '58 ปี', hn: 'HN002', room: '102', image: '/api/placeholder/80/80' },
    { id: 3, patient_id: 'P003', prefix: 'นางสาว', firstname: 'วิภา', lastname: 'รักดี', age: '45 ปี', hn: 'HN003', room: '103', image: '/api/placeholder/80/80' }
  ]);

  // รวมหัตถการทั้งหมดพร้อมระบุว่าใครสามารถทำได้
  const procedureItems = [
    { name: "ทำแผลเจาะคอ", canPerform: "nurse" },
    { name: "ทำแผลหน้าท้อง", canPerform: "nurse" },
    { name: "ทำแผลขนาดเล็ก", canPerform: "nurse" },
    { name: "ทำแผลขนาดกลาง", canPerform: "nurse" },
    { name: "ทำแผลขนาดใหญ่", canPerform: "nurse" },
    { name: "ให้ออกซิเจน (วัน)", canPerform: "nurse" },
    { name: "ให้ออกซิเจน (ชั่วโมง)", canPerform: "nurse", hasSubOption: true, subType: "hour" },
    { name: "ดูดเสมหะ", canPerform: "both" },
    { name: "พ่นยา", canPerform: "both" },
    { name: "ตัดไหม", canPerform: "nurse" },
    { name: "ใส่สาย Foley", canPerform: "nurse" },
    { name: "สวนปัสสาวะทิ้ง", canPerform: "nurse" },
    { name: "สวนล้างกระเพาะปัสสาวะ", canPerform: "nurse" },
    { name: "ใส่สาย NG", canPerform: "nurse" },
    { name: "เจาะเลือด", canPerform: "nurse" },
    { name: "ฉีดยา SC/ID", canPerform: "nurse" },
    { name: "ฉีดยา IM", canPerform: "nurse" },
    { name: "ฉีดยา IV", canPerform: "nurse" },
    { name: "เครื่อง Infustion Pump NG", canPerform: "both", hasSubOption: true, subType: "machine_ng" },
    { name: "เครื่อง Infustion Pump IV", canPerform: "nurse", hasSubOption: true, subType: "machine_iv" },
    { name: "ให้สารน้ำทางหลอดเลือดดำ IV", canPerform: "nurse" },
    { name: "EKG", canPerform: "nurse" },
    { name: "เตียงลม", canPerform: "nurse" },
    { name: "ค่าแพทย์ตรวจเยี่ยมนอกระบบ", canPerform: "nurse" },
    { name: "ค่านักโภชนาการเยี่ยมนอกระบบ", canPerform: "nurse" },
    { name: "Flush สาย IV(NSS lock)", canPerform: "nurse" },
    { name: "หลอดตา", canPerform: "nurse" },
    { name: "เหน็บยา", canPerform: "nurse" },
    { name: "ดูดเสมหะก่อน Feed", canPerform: "nurse_aid" },
    { name: "ดูสาย Foley", canPerform: "nurse_aid" },
    { name: "พลิกตะแคงตัว", canPerform: "nurse_aid" },
    { name: "สวนอุจจาระ Enema", canPerform: "nurse_aid" },
    { name: "สวนอุจจาระ Evacuate", canPerform: "nurse_aid" },
    { name: "เจาะ DTX เครื่องคนไข้", canPerform: "nurse_aid" },
    { name: "เจาะ DTX (ใช้เครื่องศูนย์รวมเวชภัณฑ์) (ครั้ง)", canPerform: "nurse_aid" },
    { name: "NA เวรติดตามส่งผู้ป่วย", canPerform: "nurse_aid" },
    { name: "ญาติขอผ้าห่ม", canPerform: "nurse_aid" },
    { name: "ญาติขอผ้าเช็ดตัว", canPerform: "nurse_aid" },
    { name: "หัตถการอื่นๆ", canPerform: "both" }
  ];

  const otherColumns = [
    "อาบน้ำ / เช็ดตัว", "สระผม", "ให้ยาก่อนอาหารเช้า", "ให้ยาหลังอาหารเช้า",
    "ให้ยาก่อนอาหารเที่ยง", "ให้ยาหลังอาหารเที่ยง", "ให้ยาก่อนอาหารเย็น", "ให้ยาหลังอาหารเย็น",
    "ให้ยาก่อนนอน", "ให้อาหารทางสายยาง", "ให้น้ำระหว่างมื้อ", "ป้อนอาหารให้คนไข้",
    "เปลี่ยนผ้าอ้อม", "พลิกตะแคงตัว", "พยาบาลตรวจเยี่ยมประเมินอาการประจำเวร/แรกรับ",
    "ตรวจเยี่ยมประเมินอาการประจำเวร", "ทำความสะอาด Unit ผู้ป่วยประจำวัน", "หัตถการอื่นๆ"
  ];

  const feedMachines = [
    "1135479", "1146019", "1127476", "1135371", "1127261", "1145984",
    "1127313", "1148468", "1148599", "1148575", "1148572"
  ];

  const ivMachines = [
    "1172034", "01172057", "660217001", "650404001", "01172039", "01164829", "01164805"
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(new Date().toLocaleTimeString('th-TH'));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const filteredPatients = patients.filter(p =>
    p.firstname.toLowerCase().includes(searchText.toLowerCase()) ||
    p.lastname.toLowerCase().includes(searchText.toLowerCase())
  );

  const handleProcedureToggle = (item) => {
    const exists = selectedProcedures.find(p => p.name === item.name);
    
    if (exists) {
      // ลบออก
      setSelectedProcedures(selectedProcedures.filter(p => p.name !== item.name));
      
      // รีเซ็ต sub-options
      if (item.name === 'ให้ออกซิเจน (ชั่วโมง)') {
        setShowOxygenOptions(false);
        setOxygenHour('');
      } else if (item.name === 'เครื่อง Infustion Pump NG') {
        setShowInfusionNGOptions(false);
        setInfusionNG('');
      } else if (item.name === 'เครื่อง Infustion Pump IV') {
        setShowInfusionIVOptions(false);
        setInfusionIV('');
      }
    } else {
      // เพิ่มเข้า - กำหนดค่าเริ่มต้นตาม canPerform
      const defaultPerformer = item.canPerform === 'both' ? 'nurse' : item.canPerform;
      setSelectedProcedures([...selectedProcedures, { 
        name: item.name, 
        performedBy: defaultPerformer,
        canPerform: item.canPerform,
        hasSubOption: item.hasSubOption,
        subType: item.subType
      }]);
      
      // แสดง sub-options
      if (item.name === 'ให้ออกซิเจน (ชั่วโมง)') setShowOxygenOptions(true);
      else if (item.name === 'เครื่อง Infustion Pump NG') setShowInfusionNGOptions(true);
      else if (item.name === 'เครื่อง Infustion Pump IV') setShowInfusionIVOptions(true);
    }
  };

  const handlePerformerChange = (procedureName, performer) => {
    setSelectedProcedures(selectedProcedures.map(p => 
      p.name === procedureName ? { ...p, performedBy: performer } : p
    ));
  };

  const handleOtherCheckbox = (item) => {
    if (checkedOther.includes(item)) {
      setCheckedOther(checkedOther.filter(i => i !== item));
    } else {
      setCheckedOther([...checkedOther, item]);
    }
  };

  const confirmProcedures = () => {
    // อัพเดทข้อมูล sub-options
    const updated = selectedProcedures.map(proc => {
      if (proc.name === 'ให้ออกซิเจน (ชั่วโมง)' && oxygenHour) {
        return { ...proc, displayName: `ให้ออกซิเจน ${oxygenHour} (ชั่วโมง)` };
      } else if (proc.name === 'เครื่อง Infustion Pump NG' && infusionNG) {
        return { ...proc, displayName: `เครื่อง Infustion Pump NG หมายเลขเครื่อง ${infusionNG}` };
      } else if (proc.name === 'เครื่อง Infustion Pump IV' && infusionIV) {
        return { ...proc, displayName: `เครื่อง Infustion Pump IV หมายเลขเครื่อง ${infusionIV}` };
      }
      return { ...proc, displayName: proc.name };
    });
    setSelectedProcedures(updated);
    setShowProcedureModal(false);
  };

  const handleSubmit = () => {
    if (!selectedPatient) {
      alert('กรุณาเลือกข้อมูลคนไข้');
      return;
    }
    setShowConfirmDialog(true);
  };

  const confirmSubmit = () => {
    alert('บันทึกข้อมูลสำเร็จ');
    resetForm();
    setShowConfirmDialog(false);
  };

  const resetForm = () => {
    setSelectedPatient(null);
    setIntolerance('-');
    setNote('');
    setSelectedProcedures([]);
    setCheckedOther([]);
    setOxygenHour('');
    setInfusionNG('');
    setInfusionIV('');
    setShowOxygenOptions(false);
    setShowInfusionNGOptions(false);
    setShowInfusionIVOptions(false);
  };

  const getPerformerLabel = (performer) => {
    if (performer === 'nurse') return 'พยาบาล';
    if (performer === 'nurse_aid') return 'ผู้ช่วย';
    return '';
  };

  return (
    <div className="min-h-screen bg-gray-50">
    

      <div className="pt-16 pb-24 px-6 max-w-2xl mx-auto">
        {/* Date */}
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">วันที่</label>
          <div className="bg-white border rounded-lg p-3 flex items-center justify-between">
            <span>{date}</span>
            <Calendar size={20} className="text-gray-400" />
          </div>
        </div>

        {/* Time */}
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">เวลา</label>
          <div className="bg-white border rounded-lg p-3 flex items-center justify-between">
            <span>{time}</span>
            <Clock size={20} className="text-gray-400" />
          </div>
        </div>

        {/* Patient Selection */}
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">ชื่อ - นามสกุล</label>
          <div 
            className="bg-white border rounded-lg p-4 flex items-center gap-3 cursor-pointer hover:bg-gray-50"
            onClick={() => setShowPatientModal(true)}
          >
            {selectedPatient ? (
              <>
                <img src={selectedPatient.image} alt="" className="w-12 h-12 rounded-full object-cover" />
                <div className="flex-1">
                  <p className="font-medium">{selectedPatient.prefix}{selectedPatient.firstname} {selectedPatient.lastname}</p>
                </div>
                <ChevronDown size={20} className="text-gray-400" />
              </>
            ) : (
              <>
                <User size={40} className="text-gray-300" />
                <span className="flex-1 text-gray-500">กรุณาเลือกข้อมูลคนไข้</span>
                <ChevronDown size={20} className="text-gray-400" />
              </>
            )}
          </div>
        </div>

        {selectedPatient && (
          <>
            {/* HN */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">HN</label>
              <input
                type="text"
                value={selectedPatient.hn}
                readOnly
                className="w-full bg-gray-100 border rounded-lg p-3"
              />
            </div>

            {/* Full Name */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">Name - Surname</label>
              <input
                type="text"
                value={`${selectedPatient.prefix}${selectedPatient.firstname} ${selectedPatient.lastname}`}
                readOnly
                className="w-full bg-gray-100 border rounded-lg p-3"
              />
            </div>

            {/* Age */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">อายุ</label>
              <input
                type="text"
                value={selectedPatient.age}
                readOnly
                className="w-full bg-gray-100 border rounded-lg p-3"
              />
            </div>

            {/* Drug Intolerance */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">ประวัติการแพ้ยา</label>
              <textarea
                value={intolerance}
                onChange={(e) => setIntolerance(e.target.value)}
                className="w-full border rounded-lg p-3 resize-none"
                rows="2"
              />
            </div>

            {/* Room */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">ห้อง</label>
              <input
                type="text"
                value={selectedPatient.room}
                readOnly
                className="w-full bg-gray-100 border rounded-lg p-3"
              />
            </div>

            {/* หัตถการพยาบาล (รวมกัน) */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">หัตถการพยาบาล</label>
              <div 
                className="bg-white border rounded-lg p-3 cursor-pointer hover:bg-gray-50 flex justify-between items-center"
                onClick={() => setShowProcedureModal(true)}
              >
                <span className="text-gray-700">
                  {selectedProcedures.length > 0 
                    ? `เลือกแล้ว ${selectedProcedures.length} รายการ` 
                    : 'เลือกหัตถการ'}
                </span>
                <ChevronDown size={20} className="text-gray-400" />
              </div>
              
              {/* แสดงรายการที่เลือก */}
              {selectedProcedures.length > 0 && (
                <div className="mt-2 space-y-2">
                  {selectedProcedures.map((proc, idx) => (
                    <div key={idx} className="bg-blue-50 border border-blue-200 rounded-lg p-2 text-sm">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{proc.displayName || proc.name}</span>
                        <span className="text-blue-600 text-xs">
                          ({getPerformerLabel(proc.performedBy)})
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Other Procedures */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">หัตถการที่ไม่คิดเงิน</label>
              <div 
                className="bg-white border rounded-lg p-3 cursor-pointer hover:bg-gray-50 flex justify-between items-center"
                onClick={() => setShowOtherModal(true)}
              >
                <span className="text-gray-700">{checkedOther.length > 0 ? checkedOther.join(', ') : 'เลือกหัตถการ'}</span>
                <ChevronDown size={20} className="text-gray-400" />
              </div>
            </div>

            {/* Note */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">หมายเหตุ</label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="w-full border rounded-lg p-3 resize-none"
                rows="3"
              />
            </div>

            {/* Submit Button */}
            <button
              onClick={handleSubmit}
              className="w-full bg-blue-500 hover:bg-blue-600 text-white rounded-full py-3 font-medium transition-colors"
            >
              Submit
            </button>
          </>
        )}
      </div>

      {/* Patient Selection Modal */}
      {showPatientModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-md max-h-[80vh] overflow-hidden flex flex-col">
            <div className="p-4 border-b flex justify-between items-center">
              <h2 className="text-lg font-semibold">กรุณาเลือกคนไข้</h2>
              <button onClick={() => setShowPatientModal(false)}>
                <X size={24} />
              </button>
            </div>
            <div className="p-4 border-b">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="ค้นหาชื่อ"
                  value={searchText}
                  onChange={(e) => setSearchText(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border rounded-lg"
                />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-4">
              {filteredPatients.map(patient => (
                <div
                  key={patient.id}
                  onClick={() => {
                    setSelectedPatient(patient);
                    setShowPatientModal(false);
                    setSearchText('');
                  }}
                  className="flex items-center gap-3 p-3 hover:bg-gray-50 rounded-lg cursor-pointer mb-2"
                >
                  <img src={patient.image} alt="" className="w-12 h-12 rounded-full object-cover" />
                  <div>
                    <p className="font-medium">{patient.prefix}{patient.firstname} {patient.lastname}</p>
                    <p className="text-sm text-gray-500">HN: {patient.hn} | ห้อง: {patient.room}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Procedure Modal (รวมกัน) */}
      {showProcedureModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-2 sm:p-4">
          <div className="bg-white rounded-lg w-full max-w-lg h-[90vh] sm:h-[85vh] overflow-hidden flex flex-col">
            <div className="p-3 sm:p-4 border-b flex-shrink-0">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base sm:text-lg font-semibold">เลือกหัตถการพยาบาล</h2>
                  <p className="text-xs sm:text-sm text-gray-500 mt-1">เลือกหัตถการและระบุผู้ปฏิบัติ</p>
                </div>
                <button onClick={() => setShowProcedureModal(false)} className="sm:hidden">
                  <X size={24} />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-3 sm:p-4 min-h-0">
              {procedureItems.map((item, idx) => {
                const isChecked = selectedProcedures.find(p => p.name === item.name);
                
                return (
                  <div key={idx} className="mb-2 sm:mb-3 border-b pb-2 sm:pb-3">
                    <div className="flex items-start gap-2">
                      <input
                        type="checkbox"
                        checked={!!isChecked}
                        onChange={() => handleProcedureToggle(item)}
                        className="w-4 h-4 mt-1 flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <span className="font-medium text-sm sm:text-base break-words">{item.name}</span>
                        
                        {/* แสดง dropdown เลือกผู้ปฏิบัติ ถ้า canPerform = 'both' */}
                        {isChecked && item.canPerform === 'both' && (
                          <select
                            value={isChecked.performedBy}
                            onChange={(e) => handlePerformerChange(item.name, e.target.value)}
                            className="mt-2 w-full border rounded px-2 py-1.5 text-xs sm:text-sm"
                          >
                            <option value="nurse">พยาบาล</option>
                            <option value="nurse_aid">ผู้ช่วยพยาบาล</option>
                          </select>
                        )}
                        
                        {/* แสดงป้ายผู้ปฏิบัติ ถ้าไม่ใช่ both */}
                        {isChecked && item.canPerform !== 'both' && (
                          <div className="mt-1">
                            <span className="inline-block bg-blue-100 text-blue-700 text-xs px-2 py-0.5 sm:py-1 rounded">
                              {getPerformerLabel(item.canPerform)}
                            </span>
                          </div>
                        )}
                        
                        {/* Sub-options */}
                        {item.name === 'ให้ออกซิเจน (ชั่วโมง)' && isChecked && showOxygenOptions && (
                          <div className="mt-2 space-y-1 ml-2 max-h-32 overflow-y-auto">
                            {[1,2,3,4,5,6,7,8,9,10,11,12,13].map(hour => (
                              <label key={hour} className="flex items-center gap-2">
                                <input
                                  type="radio"
                                  name="oxygen"
                                  value={hour}
                                  checked={oxygenHour === hour.toString()}
                                  onChange={(e) => setOxygenHour(e.target.value)}
                                  className="w-3 h-3 flex-shrink-0"
                                />
                                <span className="text-xs sm:text-sm">{hour} ชั่วโมง</span>
                              </label>
                            ))}
                          </div>
                        )}
                        
                        {item.name === 'เครื่อง Infustion Pump NG' && isChecked && showInfusionNGOptions && (
                          <div className="mt-2 space-y-1 ml-2 max-h-32 overflow-y-auto">
                            {feedMachines.map((machine, i) => (
                              <label key={i} className="flex items-center gap-2">
                                <input
                                  type="radio"
                                  name="infusionNG"
                                  value={machine}
                                  checked={infusionNG === machine}
                                  onChange={(e) => setInfusionNG(e.target.value)}
                                  className="w-3 h-3 flex-shrink-0"
                                />
                                <span className="text-xs sm:text-sm">หมายเลข {machine}</span>
                              </label>
                            ))}
                          </div>
                        )}
                        
                        {item.name === 'เครื่อง Infustion Pump IV' && isChecked && showInfusionIVOptions && (
                          <div className="mt-2 space-y-1 ml-2 max-h-32 overflow-y-auto">
                            {ivMachines.map((machine, i) => (
                              <label key={i} className="flex items-center gap-2">
                                <input
                                  type="radio"
                                  name="infusionIV"
                                  value={machine}
                                  checked={infusionIV === machine}
                                  onChange={(e) => setInfusionIV(e.target.value)}
                                  className="w-3 h-3 flex-shrink-0"
                                />
                                <span className="text-xs sm:text-sm">หมายเลข {machine}</span>
                              </label>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="p-3 sm:p-4 border-t flex gap-2 flex-shrink-0">
              <button
                onClick={() => {
                  setShowProcedureModal(false);
                  setSelectedProcedures([]);
                  setShowOxygenOptions(false);
                  setShowInfusionNGOptions(false);
                  setShowInfusionIVOptions(false);
                }}
                className="flex-1 px-3 sm:px-4 py-2 text-sm sm:text-base border rounded-lg hover:bg-gray-50"
              >
                ยกเลิก
              </button>
              <button
                onClick={confirmProcedures}
                className="flex-1 px-3 sm:px-4 py-2 text-sm sm:text-base bg-blue-500 text-white rounded-lg hover:bg-blue-600"
              >
                ยืนยัน
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Other Procedures Modal */}
      {showOtherModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-2 sm:p-4">
          <div className="bg-white rounded-lg w-full max-w-lg h-[90vh] sm:h-[85vh] overflow-hidden flex flex-col">
            <div className="p-3 sm:p-4 border-b flex-shrink-0">
              <div className="flex items-center justify-between">
                <h2 className="text-base sm:text-lg font-semibold">เลือกหัตถการที่ไม่คิดเงิน</h2>
                <button onClick={() => setShowOtherModal(false)} className="sm:hidden">
                  <X size={24} />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-3 sm:p-4 min-h-0">
              {otherColumns.map((item, idx) => (
                <div key={idx} className="mb-2 sm:mb-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={checkedOther.includes(item)}
                      onChange={() => handleOtherCheckbox(item)}
                      className="w-4 h-4 flex-shrink-0"
                    />
                    <span className="text-sm sm:text-base break-words">{item}</span>
                  </label>
                </div>
              ))}
            </div>
            <div className="p-3 sm:p-4 border-t flex gap-2 flex-shrink-0">
              <button
                onClick={() => {
                  setShowOtherModal(false);
                  setCheckedOther([]);
                }}
                className="flex-1 px-3 sm:px-4 py-2 text-sm sm:text-base border rounded-lg hover:bg-gray-50"
              >
                ยกเลิก
              </button>
              <button
                onClick={() => setShowOtherModal(false)}
                className="flex-1 px-3 sm:px-4 py-2 text-sm sm:text-base bg-blue-500 text-white rounded-lg hover:bg-blue-600"
              >
                ยืนยัน
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Dialog */}
      {showConfirmDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-2 sm:p-4">
          <div className="bg-white rounded-lg w-full max-w-lg max-h-[90vh] overflow-hidden flex flex-col">
            <div className="p-3 sm:p-4 border-b flex-shrink-0">
              <h2 className="text-base sm:text-lg font-semibold">ยืนยันการบันทึก</h2>
            </div>
            <div className="flex-1 overflow-y-auto p-3 sm:p-4 min-h-0">
              <div className="space-y-2 sm:space-y-3">
                <div className="flex justify-between py-2 border-b text-sm sm:text-base">
                  <span className="text-gray-600">วันที่:</span>
                  <span className="font-medium">{date}</span>
                </div>
                <div className="flex justify-between py-2 border-b text-sm sm:text-base">
                  <span className="text-gray-600">เวลา:</span>
                  <span className="font-medium">{time}</span>
                </div>
                <div className="flex justify-between py-2 border-b text-sm sm:text-base">
                  <span className="text-gray-600">ชื่อ - นามสกุล:</span>
                  <span className="font-medium text-right ml-2">
                    {selectedPatient?.prefix}{selectedPatient?.firstname} {selectedPatient?.lastname}
                  </span>
                </div>
                <div className="flex justify-between py-2 border-b text-sm sm:text-base">
                  <span className="text-gray-600">HN:</span>
                  <span className="font-medium">{selectedPatient?.hn}</span>
                </div>
                <div className="flex justify-between py-2 border-b text-sm sm:text-base">
                  <span className="text-gray-600">อายุ:</span>
                  <span className="font-medium">{selectedPatient?.age}</span>
                </div>
                <div className="flex justify-between py-2 border-b text-sm sm:text-base">
                  <span className="text-gray-600">ห้อง:</span>
                  <span className="font-medium">{selectedPatient?.room}</span>
                </div>
                {selectedProcedures.length > 0 && (
                  <div className="py-2 border-b">
                    <span className="text-gray-600 block mb-2 font-semibold text-sm sm:text-base">หัตถการพยาบาล:</span>
                    <div className="space-y-1">
                      {selectedProcedures.map((proc, idx) => (
                        <div key={idx} className="text-xs sm:text-sm bg-gray-50 p-2 rounded">
                          <span className="font-medium break-words">{proc.displayName || proc.name}</span>
                          <span className="text-blue-600 ml-2">
                            ({getPerformerLabel(proc.performedBy)})
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {checkedOther.length > 0 && (
                  <div className="py-2 border-b">
                    <span className="text-gray-600 block mb-1 text-sm sm:text-base">หัตถการที่ไม่คิดเงิน:</span>
                    <span className="font-medium text-xs sm:text-sm break-words">{checkedOther.join(', ')}</span>
                  </div>
                )}
                {note && (
                  <div className="py-2 border-b">
                    <span className="text-gray-600 block mb-1 text-sm sm:text-base">หมายเหตุ:</span>
                    <span className="font-medium text-xs sm:text-sm break-words">{note}</span>
                  </div>
                )}
              </div>
            </div>
            <div className="p-3 sm:p-4 border-t flex gap-2 flex-shrink-0">
              <button
                onClick={() => setShowConfirmDialog(false)}
                className="flex-1 px-3 sm:px-4 py-2 text-sm sm:text-base border rounded-lg hover:bg-gray-50"
              >
                ยกเลิก
              </button>
              <button
                onClick={confirmSubmit}
                className="flex-1 px-3 sm:px-4 py-2 text-sm sm:text-base bg-emerald-500 text-white rounded-lg hover:bg-emerald-600"
              >
                ยืนยัน
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PatientProcedureForm;